# 🧠 Gémeo Digital — Rodrigo Granadeiro Ramos

> *"O gémeo digital não substitui a pessoa — complementa-a, representa-a e torna o seu conhecimento acessível."*

---

## 📌 Sobre este Vault

Este vault documenta o projeto **Gémeo Digital de Rodrigo Granadeiro Ramos**, desenvolvido no âmbito da unidade curricular de **FinTech** da Coimbra Business School (ISCAC), no ano letivo de 2024/2025.

O projeto consiste na construção de um agente de inteligência artificial pessoal, composto por quatro skills especializadas, que representa fielmente a identidade, os valores, a personalidade e o conhecimento em FinTech do seu criador.

---

## 🗺️ Mapa do Vault

### Agente
- [[01 - Agente Geral]] — Identidade, percurso e competências
- [[02 - Skill Ética e Moral]] — Princípios e valores fundamentais
- [[03 - Skill Face Psicológica]] — Personalidade e estilo de comunicação
- [[04 - Agente FinTech Pessoal]] — Especialização em finanças digitais

### Técnico
- [[05 - Arquitetura Técnica]] — Como foi construído o agente
- [[07 - Referências]] — Fontes, ferramentas e recursos utilizados

### Reflexão
- [[06 - Reflexão Crítica]] — Aprendizagens, limitações e impacto futuro
- [[08 - Diário de Bordo]] — Registo cronológico do processo

---

## 🏷️ Tags do Projeto

`#gemeo-digital` `#fintech` `#IA` `#ISCAC` `#agente` `#ética` `#blockchain` `#dados`

---

## 📊 Visão Geral do Projeto

| Campo | Detalhe |
|---|---|
| **Autor** | Rodrigo Granadeiro Ramos |
| **Instituição** | Coimbra Business School — ISCAC |
| **Curso** | Ciência de Dados para a Gestão |
| **UC** | FinTech |
| **Ano letivo** | 2024/2025 |
| **Ferramentas** | Claude API · NotebookLM · Obsidian · HTML |
| **Estado** | ✅ Concluído |

---

## 🔗 Entregas do Projeto

- 🧠 **Gémeo Digital interativo** — ficheiro `gemeo_digital_rodrigo.html`
- 🎙️ **Podcast** — gerado via NotebookLM
- 🎬 **Vídeo** — gerado via NotebookLM
- 📊 **Slides** — gerados via NotebookLM
- 📓 **Vault Obsidian** — este documento

---

*Última atualização: Maio 2025*
