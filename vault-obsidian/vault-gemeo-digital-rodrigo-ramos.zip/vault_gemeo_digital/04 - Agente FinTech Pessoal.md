# 💸 Skill 4 — Agente FinTech Pessoal

#gemeo-digital #fintech #blockchain #regulação #pagamentos #mercados

> Skill de especialização do [[00 - Índice|Gémeo Digital]]. Cobre os quatro grandes domínios de FinTech: Blockchain, Investimento, Pagamentos Digitais e Regulação.

---

## O que é esta Skill?

O Agente FinTech Pessoal é a camada de conhecimento especializado do gémeo digital. Desenvolvida na UC de FinTech do ISCAC e aprofundada por interesse próprio, cobre os quatro domínios centrais das finanças digitais — sem nunca abandonar a voz e os valores pessoais do Rodrigo.

> ⚠️ **Nota importante:** Toda a análise é estritamente académica e informativa. Nunca são fornecidas recomendações de investimento diretas.

---

## 🔗 Domínio 1 — Blockchain & Criptoativos

### Arquiteturas Layer 1

| Blockchain | Consenso | Diferencial |
|---|---|---|
| Bitcoin | PoW | Reserva de valor, segurança máxima |
| Ethereum | PoS | Smart contracts, ecossistema DeFi |
| NEAR Protocol | Doomslug + PoS | Sharding Nightshade, UX simplificada |
| Solana | PoH + PoS | Alta velocidade, baixo custo |

### Conceitos-chave
- **Tokenomics:** inflação, fee burning, staking, governance, distribuição de recompensas
- **DeFi:** DEX, lending, yield farming, stablecoins, liquidez
- **NFTs e identidade Web3:** casos de uso, tokenização de ativos reais (RWA)
- **Interoperabilidade:** Rainbow Bridge (NEAR↔Ethereum), Aurora EVM, cross-chain

---

## 📈 Domínio 2 — Investimento & Mercados

### Métricas de análise on-chain
- **TVL** (Total Value Locked) — liquidez bloqueada em protocolos DeFi
- **Market Cap** — capitalização total de um ativo
- **Volume on-chain** — atividade real na rede
- **Correlação BTC/ETH** — dinâmica do mercado cripto

### Ciclos de mercado
- Halving do Bitcoin e impacto histórico nos preços
- Fases: acumulação → expansão → euforia → correção
- Índice de Fear & Greed como indicador de sentiment

### Comparação de ativos
| Tipo | Exemplos | Risco | Liquidez |
|---|---|---|---|
| Cripto (L1) | BTC, ETH, NEAR | Alto | Alta |
| Stablecoins | USDC, DAI | Baixo | Alta |
| RWA tokenizados | Imóveis, obrigações | Médio | Variável |
| Tradicional | Ações, obrigações | Variável | Alta |

---

## 💳 Domínio 3 — Pagamentos Digitais

### Evolução histórica
```
SWIFT → SEPA → Pagamentos Instantâneos → Open Banking → Blockchain → CBDC
```

### CBDCs — Moedas Digitais de Banco Central
- **Retail CBDC:** para o cidadão comum (ex: Digital Euro)
- **Wholesale CBDC:** para liquidação interbancária
- Riscos: privacidade, desintermediação bancária, cibersegurança

### PSD2 e Open Banking
- **XS2A:** acesso de terceiros às contas bancárias
- **SCA:** autenticação forte do cliente (2 fatores)
- **TPP:** prestadores terceiros autorizados (AIS, PIS)
- Impacto: democratização dos dados financeiros

### Stablecoins como instrumento de pagamento
| Stablecoin | Colateral | Emissor |
|---|---|---|
| USDC | USD (reservas) | Circle |
| USDT | USD (reservas) | Tether |
| DAI | Cripto (colateral) | MakerDAO |
| EURC | EUR (reservas) | Circle |

---

## ⚖️ Domínio 4 — Regulação & Compliance

### MiCA — Markets in Crypto-Assets Regulation
- Classificação de criptoativos: ARTs, EMTs, outros
- Obrigações de whitepaper para emissores
- Requisitos de capital e governança
- Em vigor: 2024 (EMTs) e 2025 (restantes categorias)

### RGPD aplicado a FinTech
- Privacidade by design em sistemas blockchain
- Direito ao esquecimento vs. imutabilidade da blockchain
- Consentimento explícito para dados financeiros

### AML/KYC em DeFi
- FATF Travel Rule: identificação em transferências >1000€
- Desafios da identidade descentralizada
- Soluções: zk-KYC, identidade auto-soberana (SSI)

### Sandbox Regulatório
- Modelos europeus de inovação supervisionada
- Banco de Portugal — enquadramento nacional
- ESMA — supervisão pan-europeia de cripto

---

## 🤖 Comportamento do Agente FinTech

1. Define sempre os conceitos antes de os aplicar
2. Usa exemplos práticos e casos de uso reais
3. Distingue claramente análise académica de aconselhamento
4. Compara sempre que possível — tecnologias, regulações, modelos
5. Alerta quando dados ou regulações possam estar desatualizados
6. Mantém o tom pessoal — técnico mas acessível

---

## 🔗 Ligações

- [[01 - Agente Geral]] — Base académica em FinTech no ISCAC
- [[02 - Skill Ética e Moral]] — Ética aplicada a FinTech
- [[05 - Arquitetura Técnica]] — Como esta skill foi implementada tecnicamente
- [[07 - Referências]] — Fontes e leituras recomendadas
