# 📚 Referências

#gemeo-digital #referências #fontes #ferramentas #leituras

> Fontes, ferramentas e recursos utilizados no desenvolvimento do [[00 - Índice|Gémeo Digital]].

---

## 🛠️ Ferramentas Utilizadas

| Ferramenta | Uso no projeto | Link |
|---|---|---|
| **Claude (Anthropic)** | Geração do system prompt, código HTML e documentação | claude.ai |
| **NotebookLM (Google)** | Geração de podcast, vídeo e slides | notebooklm.google.com |
| **Obsidian** | Documentação e vault do projeto | obsidian.md |
| **Anthropic API** | Motor do gémeo digital na interface HTML | console.anthropic.com |
| **Discord** | Partilha e apresentação ao professor | discord.com |
| **Google Drive** | Armazenamento e partilha dos ficheiros media | drive.google.com |

---

## 📖 Referências Académicas — FinTech

### Blockchain & Criptoativos
- Nakamoto, S. (2008). *Bitcoin: A Peer-to-Peer Electronic Cash System*
- Buterin, V. (2013). *Ethereum White Paper*
- NEAR Protocol. *Nightshade: Near Protocol Sharding Design* — near.org
- Szabo, N. (1994). *Smart Contracts*

### Regulação
- European Parliament (2023). *Markets in Crypto-Assets Regulation (MiCA)* — EUR-Lex
- European Commission (2018). *General Data Protection Regulation (GDPR)*
- European Banking Authority (2019). *Guidelines on PSD2 Strong Customer Authentication*
- FATF (2021). *Updated Guidance for a Risk-Based Approach to Virtual Assets*

### Pagamentos Digitais
- BIS (2021). *Central Bank Digital Currencies: Foundational Principles and Core Features*
- ECB (2023). *Progress on the Investigation Phase of a Digital Euro*
- European Commission (2022). *Proposal for a Revised Payment Services Directive (PSD3)*

### Gémeos Digitais e IA
- Grieves, M. (2014). *Digital Twin: Manufacturing Excellence through Virtual Factory Replication*
- Russell, S. & Norvig, P. (2020). *Artificial Intelligence: A Modern Approach* (4ª ed.)

---

## 🌐 Recursos Online

### Blockchain & DeFi
- [CoinGecko](https://coingecko.com) — métricas de mercado cripto
- [DeFi Llama](https://defillama.com) — TVL e métricas DeFi
- [NEAR Explorer](https://explorer.near.org) — dados on-chain NEAR
- [Etherscan](https://etherscan.io) — explorador Ethereum

### Regulação
- [EUR-Lex](https://eur-lex.europa.eu) — legislação europeia
- [ESMA](https://esma.europa.eu) — autoridade de mercados
- [Banco de Portugal](https://bportugal.pt) — regulador nacional

### IA e Prompting
- [Anthropic Docs](https://docs.anthropic.com) — documentação da API
- [Anthropic Prompt Engineering Guide](https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/overview)

---

## 📰 Leituras Recomendadas

Para aprofundar os temas abordados no gémeo digital:

**FinTech Geral**
- *The Fintech Book* — Susanne Chishti & Janos Barberis
- *Digital Gold* — Nathaniel Popper (Bitcoin)
- *The Bitcoin Standard* — Saifedean Ammous

**IA e Identidade Digital**
- *The Age of Surveillance Capitalism* — Shoshana Zuboff
- *Human Compatible* — Stuart Russell
- *Atlas of AI* — Kate Crawford

**Regulação Cripto**
- *Cryptoassets: The Innovative Investor's Guide* — Chris Burniske & Jack Tatar

---

## 🔗 Ligações

- [[00 - Índice]] — Visão geral do projeto
- [[04 - Agente FinTech Pessoal]] — Onde este conhecimento é aplicado
- [[05 - Arquitetura Técnica]] — Ferramentas técnicas detalhadas
- [[06 - Reflexão Crítica]] — Perspetivas futuras de investigação
