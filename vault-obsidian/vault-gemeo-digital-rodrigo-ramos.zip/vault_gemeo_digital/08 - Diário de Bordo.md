# 📔 Diário de Bordo

#gemeo-digital #processo #diário #cronologia #decisões

> Registo cronológico do processo de construção do [[00 - Índice|Gémeo Digital]]. Documenta decisões tomadas, desafios encontrados e aprendizagens ao longo do projeto.

---

## Como ler este diário

Cada entrada regista um momento relevante do projeto — uma decisão, um obstáculo, uma descoberta ou uma reflexão. O objetivo é mostrar o *processo*, não apenas o resultado final.

---

## 📅 Entrada 1 — Início do Projeto

**Tema:** Primeiro contacto com o conceito de Gémeo Digital

**O que aconteceu:**
O professor apresentou o desafio: construir um gémeo digital pessoal com pelo menos duas skills especializadas — uma de ética e moral, e outra de face psicológica — integrado com um agente FinTech pessoal.

**Primeiras questões:**
- O que é exatamente um gémeo digital em contexto de IA?
- Como transformar uma identidade humana num system prompt eficaz?
- Que ferramentas usar — Claude? GPT? Outro modelo?

**Decisão tomada:**
Usar Claude (Anthropic) como base, dado o conhecimento prévio da plataforma e a qualidade dos modelos para seguir instruções complexas.

**Aprendizagem:**
A construção de um agente começa muito antes do código — começa na reflexão sobre quem se é e o que se valoriza.

---

## 📅 Entrada 2 — Construção do System Prompt

**Tema:** Definição das 4 skills e estrutura do prompt

**O que aconteceu:**
Após recolher o CV e definir os domínios FinTech pretendidos (Blockchain, Pagamentos, Mercados, Regulação), foi construído o system prompt completo em quatro camadas.

**Desafios encontrados:**
- Dificuldade em capturar a "voz" natural sem soar artificial
- Equilíbrio entre detalhe suficiente e prompt demasiado longo
- Como garantir que o agente reconhece os seus limites (ex: não aconselha investimentos)

**Decisões tomadas:**
- Estrutura em 4 camadas explícitas com cabeçalhos claros
- Regras gerais no final para comportamento consistente
- Disclaimers éticos embutidos na skill FinTech

**Aprendizagem:**
Um bom system prompt não é uma lista de factos — é uma narrativa de identidade com regras claras de comportamento.

---

## 📅 Entrada 3 — Interface HTML Externa

**Tema:** Criação da interface para uso fora do Claude.ai

**O que aconteceu:**
O professor pediu algo que pudesse ser usado externamente. Foi desenvolvido um ficheiro HTML único com interface de chat, seletor de skills, prompts rápidos e integração com a API da Anthropic.

**Desafios encontrados:**
- Erro inicial: modelo `claude-sonnet-4-20250514` não disponível na API pública
- Necessidade de API key — barreira de entrada para utilizadores não técnicos

**Solução:**
- Modelo corrigido para `claude-haiku-4-5-20251001`
- Documentação clara sobre como obter API key gratuita no console.anthropic.com

**Aprendizagem:**
A diferença entre o Claude.ai (produto) e a Claude API (infraestrutura) não é óbvia para utilizadores comuns — é importante documentar claramente.

---

## 📅 Entrada 4 — NotebookLM: Podcast, Vídeo e Slides

**Tema:** Geração de conteúdo multimédia com IA

**O que aconteceu:**
Foram criados ficheiros `.md` otimizados para o NotebookLM gerar automaticamente podcast, vídeo e apresentação de slides sobre o gémeo digital.

**Processo:**
1. Criação do PDF base com toda a documentação do agente
2. Criação de guião narrativo específico para vídeo (7 secções, estilo TEDx)
3. Criação de estrutura de slides (13 slides com conteúdo detalhado)
4. Upload no NotebookLM e configuração: formato Explicação, PT-PT, estilo Clássico

**Aprendizagem:**
O NotebookLM é mais eficaz quando recebe não apenas conteúdo, mas também *instruções de formato e tom*. A qualidade do output depende da qualidade do input.

---

## 📅 Entrada 5 — Discord e Apresentação ao Professor

**Tema:** Comunicação e partilha do projeto

**O que aconteceu:**
Foram preparadas mensagens formatadas para Discord para partilhar cada componente do projeto: gémeo digital (HTML), podcast, vídeo e slides.

**Decisão tomada:**
- Ficheiro HTML partilhado diretamente como anexo no Discord
- Podcast, vídeo e slides partilhados via link Google Drive
- Textos formatados com markdown Discord para aparência profissional

**Aprendizagem:**
A forma como se apresenta um projeto é tão importante quanto o projeto em si. Um Discord bem organizado transmite profissionalismo e facilita a avaliação pelo professor.

---

## 📅 Entrada 6 — Vault Obsidian

**Tema:** Documentação estruturada do projeto

**O que aconteceu:**
Para além de todas as entregas, o professor pediu documentação no Obsidian. Foi criado este vault com 8 ficheiros interligados que documentam o projeto de forma completa.

**Estrutura criada:**
- Índice central com links para todos os ficheiros
- Um ficheiro por skill
- Arquitetura técnica documentada
- Reflexão crítica honesta
- Referências académicas e de ferramentas
- Este diário de bordo

**O que o Obsidian acrescenta:**
O grafo de conhecimento gerado automaticamente pelos `[[links]]` internos mostra visualmente como as diferentes dimensões do gémeo digital estão interligadas — é uma forma de documentação que vai além do texto linear.

**Aprendizagem:**
Documentar um projeto *enquanto* se constrói seria mais eficaz do que reconstruir o processo no final. Para projetos futuros, o diário de bordo deve ser iniciado no primeiro dia.

---

## 📅 Entrada 7 — Reflexão Final antes da Reunião

**Tema:** Preparação para a apresentação ao professor (11/05/2026, 17h30)

**Checklist de entregas:**
- ✅ System prompt completo (4 skills)
- ✅ Interface HTML externa (gemeo_digital_rodrigo.html)
- ✅ PDF para NotebookLM
- ✅ Podcast gerado (NotebookLM)
- ✅ Vídeo gerado (NotebookLM)
- ✅ Slides gerados (NotebookLM)
- ✅ Mensagens Discord formatadas
- ✅ Vault Obsidian completo

**O que funcionou bem:**
- A estrutura em 4 skills dá coerência ao agente
- A interface HTML é intuitiva e fácil de usar
- O NotebookLM gerou conteúdo de qualidade a partir dos ficheiros fornecidos

**O que faria diferente:**
- Começaria o diário de bordo desde o início
- Testaria mais a interface com utilizadores externos
- Adicionaria mais profundidade à skill FinTech em regulação

**Pensamento final:**
Este projeto mostrou que construir IA útil e responsável não é apenas uma questão técnica — é uma questão de autoconhecimento, clareza de valores e atenção ao detalhe. O gémeo digital é imperfeito, como qualquer representação de uma pessoa real. Mas é honesto — e isso é o que mais importa.

---

## 🔗 Ligações

- [[00 - Índice]] — Visão geral do projeto
- [[06 - Reflexão Crítica]] — Aprofundamento das reflexões deste diário
- [[05 - Arquitetura Técnica]] — Detalhes técnicos das decisões registadas
