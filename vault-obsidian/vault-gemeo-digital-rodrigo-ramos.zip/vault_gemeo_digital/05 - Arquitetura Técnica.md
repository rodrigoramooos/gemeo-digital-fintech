# ⚙️ Arquitetura Técnica

#gemeo-digital #técnico #API #HTML #claude #arquitetura

> Documentação técnica do [[00 - Índice|Gémeo Digital]]. Descreve as três componentes que dão vida ao agente.

---

## Visão Geral

O gémeo digital é composto por três componentes técnicas que funcionam em conjunto:

```
┌─────────────────────────────────────────────────┐
│                 GÉMEO DIGITAL                   │
│                                                 │
│  ┌───────────────┐    ┌───────────────────────┐ │
│  │ System Prompt │───▶│    Interface HTML     │ │
│  │  (4 Skills)   │    │   (Browser / Local)   │ │
│  └───────────────┘    └──────────┬────────────┘ │
│                                  │              │
│                       ┌──────────▼────────────┐ │
│                       │    Claude API         │ │
│                       │  (Anthropic)          │ │
│                       └───────────────────────┘ │
└─────────────────────────────────────────────────┘
```

---

## 🧠 Componente 1 — System Prompt

O system prompt é o "cérebro" do gémeo digital. É um documento estruturado que define:

### Estrutura
```
System Prompt
├── Camada 1: Agente Geral
│   ├── Identidade e dados pessoais
│   ├── Formação académica
│   ├── Experiência profissional
│   └── Competências e interesses
├── Camada 2: Skill Ética e Moral
│   ├── 6 princípios fundamentais
│   └── Posicionamento ético em FinTech
├── Camada 3: Skill Face Psicológica
│   ├── Perfil de personalidade
│   ├── Estilo cognitivo
│   └── Estilo de comunicação
└── Camada 4: Agente FinTech Pessoal
    ├── Blockchain & Criptoativos
    ├── Investimento & Mercados
    ├── Pagamentos Digitais
    └── Regulação & Compliance
```

### Como usar no Claude Projects
1. Criar novo projeto em claude.ai
2. Colar o system prompt nas instruções do projeto
3. Todas as conversas herdam automaticamente a identidade

---

## 🌐 Componente 2 — Interface HTML Externa

Ficheiro único `gemeo_digital_rodrigo.html` que corre no browser sem instalação.

### Funcionalidades
- ✅ Seletor de skills ativo (sidebar)
- ✅ Prompts rápidos pré-configurados
- ✅ Chips de boas-vindas interativos
- ✅ Indicador de digitação animado
- ✅ Histórico de conversa por sessão
- ✅ Botão de limpar conversa
- ✅ Badge de skill ativa

### Stack técnica
| Componente | Tecnologia |
|---|---|
| Estrutura | HTML5 |
| Estilo | CSS3 (variáveis, animações) |
| Lógica | JavaScript vanilla (ES6+) |
| Tipografia | Google Fonts (DM Sans, DM Serif Display) |
| API | Anthropic Messages API |

### Fluxo de dados
```
Utilizador escreve mensagem
        ↓
JavaScript captura input
        ↓
Adiciona ao histórico local (array)
        ↓
Envia para API com system prompt ativo
        ↓
Recebe resposta em texto
        ↓
Renderiza na interface com markdown básico
        ↓
Adiciona resposta ao histórico
```

---

## 🤖 Componente 3 — Claude API (Anthropic)

### Configuração da chamada API
```javascript
fetch('https://api.anthropic.com/v1/messages', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'x-api-key': API_KEY,
    'anthropic-version': '2023-06-01'
  },
  body: JSON.stringify({
    model: 'claude-haiku-4-5-20251001',
    max_tokens: 1024,
    system: SYSTEM_PROMPT,  // skill selecionada
    messages: history        // histórico da conversa
  })
})
```

### Modelos disponíveis
| Modelo | Velocidade | Custo | Usado em |
|---|---|---|---|
| claude-haiku-4-5 | ⚡⚡⚡ | $ | Interface HTML |
| claude-sonnet-4-6 | ⚡⚡ | $$ | Claude Projects |
| claude-opus-4-6 | ⚡ | $$$ | Tarefas complexas |

### Gestão de custos
- Haiku: ~$0.001 por conversa completa
- $5 de créditos gratuitos ≈ 5000 mensagens
- Recomendado para uso académico e demos

---

## 🛠️ Ferramentas de Desenvolvimento

| Ferramenta | Uso |
|---|---|
| **Claude (claude.ai)** | Geração do código e system prompt |
| **NotebookLM** | Podcast, vídeo e slides |
| **Obsidian** | Documentação do projeto (este vault) |
| **Browser** | Execução da interface HTML |
| **Discord** | Partilha e apresentação ao professor |

---

## 🔗 Ligações

- [[00 - Índice]] — Visão geral do projeto
- [[01 - Agente Geral]] — O que o system prompt representa
- [[04 - Agente FinTech Pessoal]] — Conhecimento especializado implementado
- [[07 - Referências]] — Documentação técnica das ferramentas
